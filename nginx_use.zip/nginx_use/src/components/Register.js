import React from 'react'

function Register() {
  return (
    <div>
        HII
    </div>
  );
}

export default Register;

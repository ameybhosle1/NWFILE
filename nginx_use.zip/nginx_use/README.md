THis app shows the use of Context API which is a state management system .
it has context.js which creates context for the data to be used by Consumer and provided by provider .
It is used when we want to pass data across many Component's props or called as data drilling .

Provider component has props which passes the data where it wants to use and "value" property which to send data to the Consumer end .
